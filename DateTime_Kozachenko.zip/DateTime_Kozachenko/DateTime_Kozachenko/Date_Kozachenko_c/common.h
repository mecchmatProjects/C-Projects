/* File  Date.h */

#include <stdio.h>
#include <time.h>
#include <float.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef float DType; /* Double real type for application */

typedef int IType;    /* Integer type for application */

typedef unsigned int NType; /* Unsigned type for application */

typedef struct tm TIME;
